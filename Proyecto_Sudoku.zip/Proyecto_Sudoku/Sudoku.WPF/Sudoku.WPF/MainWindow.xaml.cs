using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Animation;
using Sudoku.Core;
using Sudoku.Core.Interfaces;
using System.Diagnostics;

namespace Sudoku.WPF;

/// <summary>
/// VISTA: Interfaz de usuario WPF
/// PATRÓN: Observer - Implementa IBoardObserver para recibir notificaciones
/// SOLID: DIP - Depende de abstracción SudokuGameController (Facade)
/// </summary>
public partial class MainWindow : Window, IBoardObserver
{
    private readonly SudokuGameController _controller;
    private TextBox[,] _cells;
    private Stopwatch _stopwatch;
    private const int SIZE = 9;

    private CancellationTokenSource? _cts;
    private bool _isAISolving = false;

    public MainWindow(SudokuGameController controller)
    {
        InitializeComponent();
        _controller = controller;
        _controller.AttachObserver(this);
        _cells = new TextBox[SIZE, SIZE];
        _stopwatch = new Stopwatch();

        _controller.GetSolver().OnStepExecuted += OnSolverStepExecuted;

        InitializeBoard();
        TxtAlgoritmo.Text = $"Algoritmo: {_controller.GetSolverAlgorithmName()}";
    }

    private void OnSolverStepExecuted(int row, int col, int value)
    {
        Dispatcher.Invoke(() =>
        {
            if (row >= 0 && row < SIZE && col >= 0 && col < SIZE && _cells[row, col] != null)
            {
                _cells[row, col].Text = value == 0 ? "" : value.ToString();
                _cells[row, col].Foreground = Brushes.Black;

                if (value != 0)
                {
                    AnimarCambioIA(_cells[row, col]);
                }
            }
        });
    }

    private void InitializeBoard()
    {
        BoardGrid.Children.Clear();
        BoardGrid.RowDefinitions.Clear();
        BoardGrid.ColumnDefinitions.Clear();

        for (int i = 0; i < SIZE; i++)
        {
            BoardGrid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            BoardGrid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
        }

        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col < SIZE; col++)
            {
                var textBox = new TextBox
                {
                    Style = (Style)FindResource("SudokuCellStyle"),
                    Tag = new Tuple<int, int>(row, col)
                };

                var thickness = new Thickness(
                    col % 3 == 0 ? 2 : 0.5,
                    row % 3 == 0 ? 2 : 0.5,
                    col == 8 ? 2 : 0.5,
                    row == 8 ? 2 : 0.5
                );
                textBox.BorderThickness = thickness;
                textBox.BorderBrush = Brushes.Black;

                textBox.PreviewTextInput += Cell_PreviewTextInput;
                textBox.TextChanged += Cell_TextChanged;
                textBox.GotFocus += Cell_GotFocus;
                textBox.LostFocus += Cell_LostFocus;

                Grid.SetRow(textBox, row);
                Grid.SetColumn(textBox, col);
                BoardGrid.Children.Add(textBox);

                _cells[row, col] = textBox;
            }
        }
    }

    private void Cell_PreviewTextInput(object sender, System.Windows.Input.TextCompositionEventArgs e)
    {
        e.Handled = !int.TryParse(e.Text, out int num) || num < 1 || num > 9;
    }

    private void Cell_TextChanged(object sender, TextChangedEventArgs e)
    {
        if (sender is TextBox textBox && textBox.Tag is Tuple<int, int> position)
        {
            int row = position.Item1;
            int col = position.Item2;

            if (int.TryParse(textBox.Text, out int value) && value >= 1 && value <= 9)
            {
                if (!_controller.MakeMove(row, col, value))
                {
                    AnimarError(textBox);
                    textBox.Background = new SolidColorBrush(Color.FromRgb(255, 205, 210)); // Rojo claro
                }
                else
                {
                    textBox.Background = Brushes.White;
                    if (!_isAISolving && _controller.CheckWin())
                    {
                        MostrarVictoria();
                    }
                }
            }
            else if (string.IsNullOrEmpty(textBox.Text))
            {
                _controller.MakeMove(row, col, 0);
                textBox.Background = Brushes.White;
            }
        }
    }

    private void AnimarError(TextBox textBox)
    {
        var animation = new DoubleAnimation
        {
            From = 0,
            To = 10,
            Duration = TimeSpan.FromMilliseconds(50),
            AutoReverse = true,
            RepeatBehavior = new RepeatBehavior(3)
        };

        var transform = new TranslateTransform();
        textBox.RenderTransform = transform;
        transform.BeginAnimation(TranslateTransform.XProperty, animation);
    }

    private void Cell_GotFocus(object sender, RoutedEventArgs e)
    {
        if (sender is TextBox textBox && !string.IsNullOrEmpty(textBox.Text))
        {
            ResaltarNumerosIguales(textBox.Text);
        }
    }

    private void Cell_LostFocus(object sender, RoutedEventArgs e)
    {
        LimpiarResaltados();
    }

    private void ResaltarNumerosIguales(string numero)
    {
        if (string.IsNullOrEmpty(numero)) return;

        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col < SIZE; col++)
            {
                var cell = _cells[row, col];
                if (cell.Text == numero && !cell.IsReadOnly)
                {
                    cell.Background = new SolidColorBrush(Color.FromRgb(255, 243, 205));
                }
                else if (cell.Text == numero && cell.IsReadOnly)
                {
                    cell.Background = new SolidColorBrush(Color.FromRgb(200, 230, 255));
                }
            }
        }
    }

    private void LimpiarResaltados()
    {
        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col < SIZE; col++)
            {
                var cell = _cells[row, col];
                if (cell.IsReadOnly)
                {
                    cell.Background = new SolidColorBrush(Color.FromRgb(227, 242, 253));
                }
                else
                {
                    cell.Background = Brushes.White;
                }
            }
        }
    }

    private void UpdateBoard()
    {
        int[,] board = _controller.Board.Board;
        int[,] initialBoard = _controller.Board.InitialBoard;

        int filledCount = 0;
        int originalCount = 0;

        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col < SIZE; col++)
            {
                int value = board[row, col];
                var cell = _cells[row, col];

                if (value != 0) filledCount++;

                cell.Text = value == 0 ? "" : value.ToString();

                bool isOriginal = initialBoard[row, col] != 0;
                if (isOriginal) originalCount++;

                cell.IsReadOnly = isOriginal;

                if (isOriginal)
                {
                    cell.Background = new SolidColorBrush(Color.FromRgb(227, 242, 253));
                    cell.Foreground = new SolidColorBrush(Color.FromRgb(25, 118, 210));
                }
                else if (value != 0)
                {
                    cell.Background = Brushes.White;
                    cell.Foreground = Brushes.Black;
                }
                else
                {
                    cell.Background = Brushes.White;
                    cell.Foreground = new SolidColorBrush(Color.FromRgb(66, 66, 66));
                }
            }
        }

        System.Diagnostics.Debug.WriteLine($"UpdateBoard: {filledCount}/81 celdas llenas, {originalCount} originales");
    }

    private async void BtnFacil_Click(object sender, RoutedEventArgs e)
    {
        if (_cts != null && !_cts.IsCancellationRequested)
        {
            _cts.Cancel();
            await Task.Delay(100);
        }

        _isAISolving = false;
        _controller.GetSolver().SetStepByStepMode(false);
        _controller.SetSolverDelay(0);
        _stopwatch.Reset();

        await Task.Run(() => _controller.NewGame(35));

        UpdateBoard();
    }

    private async void BtnMedio_Click(object sender, RoutedEventArgs e)
    {
        if (_cts != null && !_cts.IsCancellationRequested)
        {
            _cts.Cancel();
            await Task.Delay(100);
        }

        _isAISolving = false;
        _controller.GetSolver().SetStepByStepMode(false);
        _controller.SetSolverDelay(0);
        _stopwatch.Reset();

        await Task.Run(() => _controller.NewGame(45));

        UpdateBoard();
    }

    private async void BtnDificil_Click(object sender, RoutedEventArgs e)
    {
        if (_cts != null && !_cts.IsCancellationRequested)
        {
            _cts.Cancel();
            await Task.Delay(100);
        }

        _isAISolving = false;
        _controller.GetSolver().SetStepByStepMode(false);
        _controller.SetSolverDelay(0);
        _stopwatch.Reset();

        await Task.Run(() => _controller.NewGame(55));

        UpdateBoard();
    }

    private async void BtnResolver_Click(object sender, RoutedEventArgs e)
    {
        _isAISolving = true;
        _stopwatch.Restart();

        _controller.SetSolverDelay(0);

        bool solved = await _controller.SolveAutomaticallyAsync(false, CancellationToken.None);

        _stopwatch.Stop();

        UpdateBoard();

        _isAISolving = false;

        if (solved)
        {
            MostrarVictoria();
        }
    }







    private async void BtnReiniciar_Click(object sender, RoutedEventArgs e)
    {
        if (_cts != null && !_cts.IsCancellationRequested)
        {
            _cts.Cancel();
            await Task.Delay(100);
        }

        var result = MostrarDialogoConfirmacion(
            "Confirmar Reinicio",
            "¿Está seguro de querer reiniciar el juego?\nSe perderá todo el progreso actual.",
            "Sí, Reiniciar",
            "Cancelar");

        if (result)
        {
            _isAISolving = false;
            _controller.GetSolver().SetStepByStepMode(false);
            _controller.SetSolverDelay(0);

            _controller.ResetBoard();

            UpdateBoard();

            _stopwatch.Reset();
        }
    }

    private void MostrarVictoria()
    {
        AnimarVictoria();

        MostrarDialogoPersonalizado(
            "¡FELICITACIONES! 🎉",
            "Has resuelto el Sudoku correctamente.\n¡Excelente trabajo!",
            "Aceptar");
    }

    private void AnimarVictoria()
    {
        var colorAnimation = new ColorAnimation
        {
            From = Colors.White,
            To = Color.FromRgb(200, 255, 200),
            Duration = TimeSpan.FromMilliseconds(500),
            AutoReverse = true,
            RepeatBehavior = new RepeatBehavior(2)
        };

        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col < SIZE; col++)
            {
                var cell = _cells[row, col];
                var brush = new SolidColorBrush(Colors.White);
                cell.Background = brush;
                brush.BeginAnimation(SolidColorBrush.ColorProperty, colorAnimation);
            }
        }
    }



    public void OnBoardChanged(int row, int col, int value)
    {
        Dispatcher.Invoke(() =>
        {
            if (row >= 0 && row < SIZE && col >= 0 && col < SIZE)
            {
                var cell = _cells[row, col];
                cell.Text = value == 0 ? "" : value.ToString();

                AnimarCambioIA(cell);
            }
        });
    }

    private void AnimarCambioIA(TextBox cell)
    {
        var colorAnimation = new ColorAnimation
        {
            From = Color.FromRgb(255, 255, 200),
            To = Colors.White,
            Duration = TimeSpan.FromMilliseconds(300)
        };

        var brush = new SolidColorBrush(Color.FromRgb(255, 255, 200));
        cell.Background = brush;
        brush.BeginAnimation(SolidColorBrush.ColorProperty, colorAnimation);
    }

    public void OnBoardSolved()
    {
        Dispatcher.Invoke(() =>
        {
            UpdateBoard();
        });
    }

    public void OnBoardReset()
    {
        Dispatcher.Invoke(() =>
        {
            UpdateBoard();
        });
    }

    private void MostrarDialogoPersonalizado(string titulo, string mensaje, string botonTexto)
    {
        var dialogo = new Window
        {
            Title = titulo,
            Width = 400,
            Height = 200,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
            Owner = this,
            ResizeMode = ResizeMode.NoResize,
            Background = new SolidColorBrush(Color.FromRgb(26, 32, 44))
        };

        var grid = new Grid { Margin = new Thickness(20) };
        grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var txtMensaje = new TextBlock
        {
            Text = mensaje,
            FontSize = 16,
            Foreground = Brushes.White,
            TextWrapping = TextWrapping.Wrap,
            TextAlignment = TextAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center
        };
        Grid.SetRow(txtMensaje, 0);
        grid.Children.Add(txtMensaje);

        var btnAceptar = new Button
        {
            Content = botonTexto,
            Height = 40,
            FontSize = 14,
            FontWeight = FontWeights.Bold,
            Background = new SolidColorBrush(Color.FromRgb(76, 175, 80)),
            Foreground = Brushes.White,
            BorderThickness = new Thickness(0),
            Cursor = System.Windows.Input.Cursors.Hand,
            Margin = new Thickness(0, 10, 0, 0)
        };
        btnAceptar.Click += (s, e) => dialogo.Close();
        Grid.SetRow(btnAceptar, 1);
        grid.Children.Add(btnAceptar);

        dialogo.Content = grid;
        dialogo.ShowDialog();
    }

    private bool MostrarDialogoConfirmacion(string titulo, string mensaje, string botonSi, string botonNo)
    {
        bool resultado = false;
        var dialogo = new Window
        {
            Title = titulo,
            Width = 420,
            Height = 220,
            WindowStartupLocation = WindowStartupLocation.CenterOwner,
            Owner = this,
            ResizeMode = ResizeMode.NoResize,
            Background = new SolidColorBrush(Color.FromRgb(26, 32, 44))
        };

        var grid = new Grid { Margin = new Thickness(20) };
        grid.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
        grid.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

        var txtMensaje = new TextBlock
        {
            Text = mensaje,
            FontSize = 15,
            Foreground = Brushes.White,
            TextWrapping = TextWrapping.Wrap,
            TextAlignment = TextAlignment.Center,
            VerticalAlignment = VerticalAlignment.Center
        };
        Grid.SetRow(txtMensaje, 0);
        grid.Children.Add(txtMensaje);

        var panelBotones = new StackPanel
        {
            Orientation = Orientation.Horizontal,
            HorizontalAlignment = HorizontalAlignment.Center,
            Margin = new Thickness(0, 15, 0, 0)
        };

        var btnSi = new Button
        {
            Content = botonSi,
            Width = 140,
            Height = 40,
            FontSize = 14,
            FontWeight = FontWeights.Bold,
            Background = new SolidColorBrush(Color.FromRgb(244, 67, 54)),
            Foreground = Brushes.White,
            BorderThickness = new Thickness(0),
            Cursor = System.Windows.Input.Cursors.Hand,
            Margin = new Thickness(0, 0, 10, 0)
        };
        btnSi.Click += (s, e) => { resultado = true; dialogo.Close(); };

        var btnNo = new Button
        {
            Content = botonNo,
            Width = 140,
            Height = 40,
            FontSize = 14,
            FontWeight = FontWeights.Bold,
            Background = new SolidColorBrush(Color.FromRgb(96, 125, 139)),
            Foreground = Brushes.White,
            BorderThickness = new Thickness(0),
            Cursor = System.Windows.Input.Cursors.Hand,
            Margin = new Thickness(10, 0, 0, 0)
        };
        btnNo.Click += (s, e) => { resultado = false; dialogo.Close(); };

        panelBotones.Children.Add(btnSi);
        panelBotones.Children.Add(btnNo);

        Grid.SetRow(panelBotones, 1);
        grid.Children.Add(panelBotones);

        dialogo.Content = grid;
        dialogo.ShowDialog();

        return resultado;
    }
}
