﻿using System.Windows;
using Sudoku.Core;
using Sudoku.Core.Validators;
using Sudoku.Core.Algorithms;
using Sudoku.Core.Builders;

namespace Sudoku.WPF;

/// <summary>
/// APLICACIÓN: Punto de entrada de la aplicación WPF
/// PATRÓN: Dependency Injection - Configuración de dependencias
/// SOLID: DIP - Crea y conecta abstracciones (interfaces con implementaciones)
/// </summary>
public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        var validator = new SudokuValidator();
        var solver = new MRVBacktrackingSolver(validator);
        var generator = new SudokuBoardGenerator(validator, solver);
        var controller = new SudokuGameController(validator, solver, generator);

        var mainWindow = new MainWindow(controller);
        mainWindow.Show();
    }
}

