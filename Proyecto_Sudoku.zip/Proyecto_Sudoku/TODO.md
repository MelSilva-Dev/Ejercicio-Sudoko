# TODO: Simplificar interfaz Sudoku

## Cambios en MainWindow.xaml

- [x] Cambiar gradientes de colores a rosado/púrpura
- [ ] Mover panel de control arriba como barra horizontal
- [x] Eliminar botón "PASO A PASO"
- [x] Eliminar slider de velocidad y texto de velocidad
- [x] Eliminar panel de control IA (pausar/detener) - no presente
- [x] Simplificar panel: mantener dificultad, resolver, reiniciar, estadísticas
- [x] Eliminar barra inferior con estadísticas y mensaje
- [ ] Ajustar layout: fila superior para menú y panel horizontal, medio para tablero

## Cambios en MainWindow.xaml.cs

- [x] Remover código de BtnPasoAPaso_Click (eliminado handler)
- [x] Remover código de SliderVelocidad_ValueChanged (eliminado handler)
- [x] Remover código de BtnPausar_Click y BtnDetener_Click - no presente
- [ ] Remover variables relacionadas: \_cts, \_velocidadIA, \_isPaused, \_isAISolving
- [ ] Remover referencias a panel de control IA
- [ ] Actualizar métodos para no usar funciones eliminadas

## Pruebas

- [ ] Probar que la UI se vea bien
- [ ] Verificar funcionalidad básica: generar tablero, resolver, reiniciar
