using Sudoku.Core.Interfaces;
using Sudoku.Core.Models;

namespace Sudoku.Core;

/// <summary>
/// PATRÓN: Facade - Simplifica interacción con subsistemas
/// SOLID: SRP (Single Responsibility) - Coordina el juego
/// SOLID: DIP (Dependency Inversion) - Depende de abstracciones (interfaces)
/// </summary>
public class SudokuGameController
{
    private readonly SudokuBoard _board;
    private readonly ISudokuValidator _validator;
    private readonly ISudokuSolver _solver;
    private readonly IBoardGenerator _generator;

    public SudokuBoard Board => _board;
    public ISudokuValidator Validator => _validator;

    public SudokuGameController(
        ISudokuValidator validator,
        ISudokuSolver solver,
        IBoardGenerator generator)
    {
        _validator = validator ?? throw new ArgumentNullException(nameof(validator));
        _solver = solver ?? throw new ArgumentNullException(nameof(solver));
        _generator = generator ?? throw new ArgumentNullException(nameof(generator));

        _board = new SudokuBoard();
    }

    public void AttachObserver(IBoardObserver observer)
    {
        _board.AttachObserver(observer);
    }

    public void DetachObserver(IBoardObserver observer)
    {
        _board.DetachObserver(observer);
    }

    public void NewGame(int difficulty)
    {
        int[,] newBoard = _generator.Generate(difficulty);
        _board.Initialize(newBoard);
    }

    public void LoadCustomBoard(int[,] board)
    {
        if (!_validator.IsValidBoard(board))
        {
            throw new ArgumentException("El tablero proporcionado no es válido");
        }
        _board.Initialize(board);
    }

    public bool MakeMove(int row, int col, int value)
    {
        if (!_board.SetValue(row, col, value))
        {
            return false;
        }

        if (value != 0 && !_validator.IsValidPlacement(_board.Board, row, col, value))
        {
            _board.SetValue(row, col, 0);
            return false;
        }

        return true;
    }

    public bool CheckWin()
    {
        return _validator.IsBoardComplete(_board.Board);
    }

    public async Task<bool> SolveAutomaticallyAsync(bool stepByStep = false, CancellationToken cancellationToken = default)
    {
        _solver.SetStepByStepMode(stepByStep);

        int[,] boardToSolve = (int[,])_board.Board.Clone();

        bool solved = await _solver.SolveAsync(boardToSolve, cancellationToken);

        if (solved)
        {
            _board.CopySolution(boardToSolve);
            _board.MarkAsSolved();
        }

        _solver.SetStepByStepMode(false);

        return solved;
    }

    public ISudokuSolver GetSolver()
    {
        return _solver;
    }

    public void ResetBoard()
    {
        _board.Reset();
    }

    public void ClearBoard()
    {
        _board.Clear();
    }

    public string GetSolverAlgorithmName()
    {
        return _solver.GetAlgorithmName();
    }

    public void SetSolverDelay(int milliseconds)
    {
        _solver.SetDelay(milliseconds);
    }

    public void UpdateCellDirect(int row, int col, int value)
    {
        _board.GetBoardReference()[row, col] = value;
        _board.NotifyCellChanged(row, col, value);
    }
}
