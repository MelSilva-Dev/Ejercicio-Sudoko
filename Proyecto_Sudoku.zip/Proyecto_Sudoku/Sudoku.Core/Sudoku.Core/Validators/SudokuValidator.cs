using Sudoku.Core.Interfaces;

namespace Sudoku.Core.Validators;

/// <summary>
/// VALIDADOR: Implementa reglas del Sudoku
/// SOLID: SRP - Responsabilidad única: validar reglas del juego
/// SOLID: ISP - Implementa interfaz específica ISudokuValidator
/// </summary>
public class SudokuValidator : ISudokuValidator
{
    private const int SIZE = 9;
    private const int SUBGRID_SIZE = 3;

    public bool IsValidPlacement(int[,] board, int row, int col, int num)
    {
        if (num < 1 || num > 9)
        {
            return false;
        }

        if (!IsValidInRow(board, row, col, num))
        {
            return false;
        }

        if (!IsValidInColumn(board, row, col, num))
        {
            return false;
        }

        if (!IsValidInSubgrid(board, row, col, num))
        {
            return false;
        }

        return true;
    }

    public bool IsValidBoard(int[,] board)
    {
        if (board.GetLength(0) != SIZE || board.GetLength(1) != SIZE)
        {
            return false;
        }

        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col < SIZE; col++)
            {
                int value = board[row, col];
                if (value != 0)
                {
                    board[row, col] = 0;
                    bool valid = IsValidPlacement(board, row, col, value);
                    board[row, col] = value;

                    if (!valid)
                    {
                        return false;
                    }
                }
            }
        }

        return true;
    }

    public bool IsBoardComplete(int[,] board)
    {
        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col < SIZE; col++)
            {
                if (board[row, col] == 0)
                {
                    return false;
                }
            }
        }

        return IsValidBoard(board);
    }

    private bool IsValidInRow(int[,] board, int row, int col, int num)
    {
        for (int c = 0; c < SIZE; c++)
        {
            if (c != col && board[row, c] == num)
            {
                return false;
            }
        }
        return true;
    }

    private bool IsValidInColumn(int[,] board, int row, int col, int num)
    {
        for (int r = 0; r < SIZE; r++)
        {
            if (r != row && board[r, col] == num)
            {
                return false;
            }
        }
        return true;
    }

    private bool IsValidInSubgrid(int[,] board, int row, int col, int num)
    {
        int startRow = row - row % SUBGRID_SIZE;
        int startCol = col - col % SUBGRID_SIZE;

        for (int r = startRow; r < startRow + SUBGRID_SIZE; r++)
        {
            for (int c = startCol; c < startCol + SUBGRID_SIZE; c++)
            {
                if ((r != row || c != col) && board[r, c] == num)
                {
                    return false;
                }
            }
        }
        return true;
    }
}
