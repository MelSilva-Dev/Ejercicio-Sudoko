namespace Sudoku.Core.Models;

/// <summary>
/// MODELO: Entidad del dominio - Representa una celda del Sudoku
/// SOLID: SRP - Responsabilidad única: almacenar datos de una celda
/// </summary>
public class Cell
{
    public int Row { get; set; }
    public int Col { get; set; }
    public int Value { get; set; }
    public bool IsFixed { get; set; }
    public HashSet<int> PossibleValues { get; set; }

    public Cell(int row, int col, int value = 0, bool isFixed = false)
    {
        Row = row;
        Col = col;
        Value = value;
        IsFixed = isFixed;
        PossibleValues = new HashSet<int>();

        if (value == 0)
        {
            for (int i = 1; i <= 9; i++)
            {
                PossibleValues.Add(i);
            }
        }
    }

    public Cell Clone()
    {
        var clone = new Cell(Row, Col, Value, IsFixed);
        clone.PossibleValues = new HashSet<int>(PossibleValues);
        return clone;
    }
}
