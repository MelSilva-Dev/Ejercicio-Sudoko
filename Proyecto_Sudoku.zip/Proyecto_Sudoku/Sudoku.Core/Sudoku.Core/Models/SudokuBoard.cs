using Sudoku.Core.Interfaces;

namespace Sudoku.Core.Models;

/// <summary>
/// MODELO: Entidad del dominio - Representa el tablero de Sudoku
/// PATRÓN: Observer (Sujeto) - Notifica cambios a observadores
/// SOLID: SRP - Responsabilidad única: gestionar estado del tablero
/// </summary>
public class SudokuBoard
{
    private const int SIZE = 9;
    private const int SUBGRID_SIZE = 3;

    private int[,] _board;
    private int[,] _initialBoard;
    private List<IBoardObserver> _observers;

    public int[,] Board => (int[,])_board.Clone();
    public int[,] InitialBoard => (int[,])_initialBoard.Clone();
    public int Size => SIZE;
    public int SubgridSize => SUBGRID_SIZE;

    internal int[,] GetBoardReference() => _board;

    public SudokuBoard()
    {
        _board = new int[SIZE, SIZE];
        _initialBoard = new int[SIZE, SIZE];
        _observers = new List<IBoardObserver>();
    }

    public void Initialize(int[,] board)
    {
        if (board.GetLength(0) != SIZE || board.GetLength(1) != SIZE)
        {
            throw new ArgumentException($"El tablero debe ser de {SIZE}x{SIZE}");
        }

        _board = (int[,])board.Clone();
        _initialBoard = (int[,])board.Clone();
        NotifyBoardReset();
    }

    public bool SetValue(int row, int col, int value)
    {
        if (row < 0 || row >= SIZE || col < 0 || col >= SIZE)
        {
            return false;
        }

        if (value < 0 || value > 9)
        {
            return false;
        }

        if (_initialBoard[row, col] != 0)
        {
            return false;
        }

        _board[row, col] = value;
        NotifyBoardChanged(row, col, value);
        return true;
    }

    public int GetValue(int row, int col)
    {
        if (row < 0 || row >= SIZE || col < 0 || col >= SIZE)
        {
            return -1;
        }
        return _board[row, col];
    }

    public bool IsCellFixed(int row, int col)
    {
        return _initialBoard[row, col] != 0;
    }

    public void Reset()
    {
        _board = (int[,])_initialBoard.Clone();
        NotifyBoardReset();
    }

    public void Clear()
    {
        _board = new int[SIZE, SIZE];
        _initialBoard = new int[SIZE, SIZE];
        NotifyBoardReset();
    }

    /// <summary>
    /// Copia la solución al tablero sin modificar el tablero inicial
    /// Usado cuando el solver termina de resolver
    /// </summary>
    public void CopySolution(int[,] solution)
    {
        if (solution.GetLength(0) != SIZE || solution.GetLength(1) != SIZE)
        {
            throw new ArgumentException($"La solución debe ser de {SIZE}x{SIZE}");
        }

        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col < SIZE; col++)
            {
                _board[row, col] = solution[row, col];
            }
        }

        int filledCells = 0;
        for (int i = 0; i < SIZE; i++)
        {
            for (int j = 0; j < SIZE; j++)
            {
                if (_board[i, j] != 0) filledCells++;
            }
        }
        System.Diagnostics.Debug.WriteLine($"CopySolution: {filledCells}/81 celdas llenas en _board");
    }

    // Observer Pattern 
    public void AttachObserver(IBoardObserver observer)
    {
        if (!_observers.Contains(observer))
        {
            _observers.Add(observer);
        }
    }

    public void DetachObserver(IBoardObserver observer)
    {
        _observers.Remove(observer);
    }

    private void NotifyBoardChanged(int row, int col, int value)
    {
        foreach (var observer in _observers)
        {
            observer.OnBoardChanged(row, col, value);
        }
    }

    private void NotifyBoardSolved()
    {
        foreach (var observer in _observers)
        {
            observer.OnBoardSolved();
        }
    }

    private void NotifyBoardReset()
    {
        foreach (var observer in _observers)
        {
            observer.OnBoardReset();
        }
    }

    public void MarkAsSolved()
    {
        NotifyBoardSolved();
    }

    public void NotifyCellChanged(int row, int col, int value)
    {
        NotifyBoardChanged(row, col, value);
    }
}
