namespace Sudoku.Core.Interfaces;

/// <summary>
/// PATRÓN: Strategy - Contrato para algoritmos de resolución intercambiables
/// SOLID: ISP - Interfaz segregada y específica para resolución
/// SOLID: OCP - Permite agregar nuevos algoritmos sin modificar código existente
/// SOLID: DIP - Abstracción de la que dependen los clientes
/// </summary>
public interface ISudokuSolver
{
    Task<bool> SolveAsync(int[,] board, CancellationToken cancellationToken = default);
    string GetAlgorithmName();
    void SetStepByStepMode(bool enabled);
    void SetDelay(int milliseconds);
    void Pause();
    void Resume();
    int DelayMs { get; set; }
    event Action<int, int, int>? OnStepExecuted;
}
