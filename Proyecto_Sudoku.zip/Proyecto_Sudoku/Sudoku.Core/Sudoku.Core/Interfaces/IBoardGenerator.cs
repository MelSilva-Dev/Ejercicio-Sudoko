namespace Sudoku.Core.Interfaces;

/// <summary>
/// CONTRATO: Interfaz de generación de tableros
/// SOLID: ISP - Interfaz pequeña y específica solo para generación
/// PATRÓN: Builder - Define métodos de construcción de tableros
/// </summary>
public interface IBoardGenerator
{
    int[,] Generate(int difficulty);
    int[,] GenerateEmpty();
}
