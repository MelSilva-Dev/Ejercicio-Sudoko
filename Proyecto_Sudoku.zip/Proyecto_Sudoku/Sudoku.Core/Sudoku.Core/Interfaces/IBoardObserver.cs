namespace Sudoku.Core.Interfaces;

/// <summary>
/// PATRÓN: Observer - Contrato para observadores del tablero
/// SOLID: ISP - Interfaz pequeña y específica solo para notificaciones
/// </summary>
public interface IBoardObserver
{
    void OnBoardChanged(int row, int col, int value);
    void OnBoardSolved();
    void OnBoardReset();
}
