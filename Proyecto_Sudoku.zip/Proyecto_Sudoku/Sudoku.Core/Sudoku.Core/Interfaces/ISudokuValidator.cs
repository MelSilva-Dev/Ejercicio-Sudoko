namespace Sudoku.Core.Interfaces;

/// <summary>
/// CONTRATO: Interfaz de validación de Sudoku
/// SOLID: ISP - Interfaz pequeña y específica solo para validación
/// SOLID: DIP - Abstracción de la que dependen validadores concretos
/// </summary>
public interface ISudokuValidator
{
    bool IsValidPlacement(int[,] board, int row, int col, int num);
    bool IsValidBoard(int[,] board);
    bool IsBoardComplete(int[,] board);
}
