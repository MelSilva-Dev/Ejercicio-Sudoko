using Sudoku.Core.Interfaces;

namespace Sudoku.Core.Builders;

/// <summary>
/// PATRÓN: Builder - Construcción compleja de tableros
/// SOLID: SRP - Responsabilidad única: generar tableros de Sudoku
/// SOLID: DIP - Depende de abstracciones (ISudokuValidator, ISudokuSolver)
/// </summary>
public class SudokuBoardGenerator : IBoardGenerator
{
    private const int SIZE = 9;
    private readonly ISudokuValidator _validator;
    private readonly ISudokuSolver _solver;
    private readonly Random _random;

    public SudokuBoardGenerator(ISudokuValidator validator, ISudokuSolver solver)
    {
        _validator = validator ?? throw new ArgumentNullException(nameof(validator));
        _solver = solver ?? throw new ArgumentNullException(nameof(solver));
        _random = new Random();
    }

    public int[,] Generate(int difficulty)
    {
        difficulty = Math.Clamp(difficulty, 20, 64);

        int[,] board = GenerateCompleteBoard();

        RemoveCells(board, difficulty);

        return board;
    }

    public int[,] GenerateEmpty()
    {
        return new int[SIZE, SIZE];
    }

    private int[,] GenerateCompleteBoard()
    {
        int[,] board = new int[SIZE, SIZE];

        FillDiagonalSubgrids(board);

        _solver.SolveAsync(board).GetAwaiter().GetResult();

        return board;
    }

    private void FillDiagonalSubgrids(int[,] board)
    {
        for (int i = 0; i < SIZE; i += 3)
        {
            FillSubgrid(board, i, i);
        }
    }

    private void FillSubgrid(int[,] board, int row, int col)
    {
        List<int> numbers = Enumerable.Range(1, 9).OrderBy(x => _random.Next()).ToList();
        int index = 0;

        for (int r = 0; r < 3; r++)
        {
            for (int c = 0; c < 3; c++)
            {
                board[row + r, col + c] = numbers[index++];
            }
        }
    }

    private void RemoveCells(int[,] board, int count)
    {
        int removed = 0;
        List<(int, int)> positions = new List<(int, int)>();

        for (int r = 0; r < SIZE; r++)
        {
            for (int c = 0; c < SIZE; c++)
            {
                positions.Add((r, c));
            }
        }

        positions = positions.OrderBy(x => _random.Next()).ToList();

        foreach (var (r, c) in positions)
        {
            if (removed >= count) break;

            int backup = board[r, c];
            board[r, c] = 0;

            int[,] testBoard = (int[,])board.Clone();
            if (_solver.SolveAsync(testBoard).GetAwaiter().GetResult())
            {
                removed++;
            }
            else
            {
                board[r, c] = backup;
            }
        }
    }
}
