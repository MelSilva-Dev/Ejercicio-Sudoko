using Sudoku.Core.Interfaces;
using Sudoku.Core.Models;

namespace Sudoku.Core.Algorithms;

/// <summary>
/// PATRÓN: Strategy Pattern - Estrategia concreta de resolución
/// IA: Algoritmo MRV (Minimum Remaining Values) + Naked Singles
/// Combina técnicas determinísticas con búsqueda heurística
/// </summary>
public class MRVBacktrackingSolver : BaseSudokuSolver
{
    public MRVBacktrackingSolver(ISudokuValidator validator) : base(validator)
    {
    }

    public override string GetAlgorithmName()
    {
        return "Backtracking con MRV (Minimum Remaining Values) - IA";
    }

    public override async Task<bool> SolveAsync(int[,] board, CancellationToken cancellationToken = default)
    {
        return await SolveWithMRVAsync(board, cancellationToken);
    }

    /// <summary>
    /// IA: Algoritmo híbrido
    /// 1. Naked Singles (determinístico) - resuelve celdas con una sola opción
    /// 2. MRV Heuristic (búsqueda) - elige celda con menos valores posibles
    /// </summary>
    private async Task<bool> SolveWithMRVAsync(int[,] board, CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();

        bool progress = true;
        while (progress)
        {
            progress = false;
            for (int row = 0; row < SIZE; row++)
            {
                for (int col = 0; col < SIZE; col++)
                {
                    if (board[row, col] == 0)
                    {
                        var possibleValues = GetPossibleValues(board, row, col);
                        if (possibleValues.Count == 1)
                        {
                            int value = possibleValues.First();
                            board[row, col] = value;
                            await NotifyStepAsync(row, col, value, cancellationToken);
                            progress = true;
                        }
                        else if (possibleValues.Count == 0)
                        {
                            return false;
                        }
                    }
                }
            }
        }

        if (IsBoardComplete(board))
        {
            return true;
        }

        var cell = FindCellWithMinimumRemainingValues(board);

        if (cell == null)
        {
            return IsBoardComplete(board);
        }

        if (cell.PossibleValues.Count == 0)
        {
            return false;
        }

        int cellRow = cell.Row;
        int cellCol = cell.Col;

        foreach (int num in cell.PossibleValues.OrderBy(x => x))
        {
            cancellationToken.ThrowIfCancellationRequested();

            if (_validator.IsValidPlacement(board, cellRow, cellCol, num))
            {
                board[cellRow, cellCol] = num;
                await NotifyStepAsync(cellRow, cellCol, num, cancellationToken);

                if (await SolveWithMRVAsync(board, cancellationToken))
                {
                    return true;
                }

                board[cellRow, cellCol] = 0;
                await NotifyStepAsync(cellRow, cellCol, 0, cancellationToken);
            }
        }

        return false;
    }

    /// <summary>
    /// IA: Heurística MRV - selecciona celda con menos valores posibles
    /// Reduce el espacio de búsqueda significativamente
    /// </summary>
    private Cell? FindCellWithMinimumRemainingValues(int[,] board)
    {
        Cell? bestCell = null;
        int minPossibilities = 10;

        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col < SIZE; col++)
            {
                if (board[row, col] == 0)
                {
                    var possibleValues = GetPossibleValues(board, row, col);
                    int count = possibleValues.Count;

                    if (count == 0)
                    {
                        System.Diagnostics.Debug.WriteLine($"MRV: CONFLICTO en celda [{row},{col}]");
                        return new Cell(row, col) { PossibleValues = new HashSet<int>() };
                    }

                    if (count < minPossibilities)
                    {
                        minPossibilities = count;
                        bestCell = new Cell(row, col);
                        bestCell.PossibleValues = possibleValues;

                        if (count == 1)
                        {
                            return bestCell;
                        }
                    }
                }
            }
        }

        return bestCell;
    }

    /// <summary>
    /// IA: Propagación de restricciones - calcula valores posibles
    /// </summary>
    private HashSet<int> GetPossibleValues(int[,] board, int row, int col)
    {
        HashSet<int> possible = new HashSet<int>();

        for (int num = 1; num <= 9; num++)
        {
            if (_validator.IsValidPlacement(board, row, col, num))
            {
                possible.Add(num);
            }
        }

        return possible;
    }

    private bool IsBoardComplete(int[,] board)
    {
        for (int row = 0; row < SIZE; row++)
        {
            for (int col = 0; col < SIZE; col++)
            {
                if (board[row, col] == 0)
                {
                    return false;
                }
            }
        }
        return true;
    }
}
