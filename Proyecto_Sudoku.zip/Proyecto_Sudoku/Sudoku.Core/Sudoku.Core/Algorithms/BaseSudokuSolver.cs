using Sudoku.Core.Interfaces;

namespace Sudoku.Core.Algorithms;

/// <summary>
/// PATRÓN: Template Method Pattern - Define esqueleto del algoritmo
/// SOLID: OCP (Open/Closed) - Extensible sin modificación
/// </summary>
public abstract class BaseSudokuSolver : ISudokuSolver
{
    protected const int SIZE = 9;
    protected const int SUBGRID_SIZE = 3;
    protected readonly ISudokuValidator _validator;
    protected bool _stepByStepMode;
    protected int _delayMs = 50;
    protected bool _isPaused = false;

    public int DelayMs
    {
        get => _delayMs;
        set => _delayMs = Math.Max(10, Math.Min(1000, value));
    }

    public event Action<int, int, int>? OnStepExecuted;

    protected BaseSudokuSolver(ISudokuValidator validator)
    {
        _validator = validator ?? throw new ArgumentNullException(nameof(validator));
        _stepByStepMode = false;
    }

    public abstract Task<bool> SolveAsync(int[,] board, CancellationToken cancellationToken = default);
    public abstract string GetAlgorithmName();

    public void SetStepByStepMode(bool enabled)
    {
        _stepByStepMode = enabled;
    }

    public void SetDelay(int milliseconds)
    {
        DelayMs = milliseconds;
    }

    public void Pause()
    {
        _isPaused = true;
    }

    public void Resume()
    {
        _isPaused = false;
    }

    protected async Task NotifyStepAsync(int row, int col, int value, CancellationToken cancellationToken = default)
    {
        if (_stepByStepMode)
        {
            cancellationToken.ThrowIfCancellationRequested();

            OnStepExecuted?.Invoke(row, col, value);

            if (_delayMs > 0)
            {
                await Task.Delay(_delayMs, cancellationToken);

                while (_isPaused)
                {
                    cancellationToken.ThrowIfCancellationRequested();
                    await Task.Delay(100, cancellationToken);
                }
            }
        }
    }

    protected bool FindEmptyCell(int[,] board, out int row, out int col)
    {
        for (row = 0; row < SIZE; row++)
        {
            for (col = 0; col < SIZE; col++)
            {
                if (board[row, col] == 0)
                {
                    return true;
                }
            }
        }
        row = -1;
        col = -1;
        return false;
    }
}
